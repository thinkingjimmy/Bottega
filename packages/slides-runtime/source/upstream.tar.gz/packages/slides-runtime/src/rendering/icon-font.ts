/** Restored application module; prepare first, initialize in original order. */
import { bindRuntimeValue, type RuntimeBindings } from "../bindings";

declare module "../bindings" {
  interface RuntimeBindings {
    iconFontGlyphs: Record<string, string>;
    iconFontCss: string;
    initializeIconFont: () => void;
  }
}

export function installRenderingIconFont(runtime: RuntimeBindings): () => void {
  var iconFontGlyphs: Record<string, string>;
  var iconFontCss: string;
  var initializeIconFont: () => void;

  bindRuntimeValue(
    runtime,
    "iconFontGlyphs",
    () => iconFontGlyphs,
    (value) => {
      iconFontGlyphs = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "iconFontCss",
    () => iconFontCss,
    (value) => {
      iconFontCss = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "initializeIconFont",
    () => initializeIconFont,
    (value) => {
      initializeIconFont = value;
    },
  );
  return () => {
    initializeIconFont = (0, runtime.initializeOnce)((): void => {
      iconFontGlyphs = JSON.parse(
        ' {"Activity":"","Add":"","AddBold":"","AddSmall":"","Agent":"","Ant":"","Archive":"","ArrowDown":"","ArrowDownCircle":"","ArrowDownSmall":"","ArrowInSquare":"","ArrowLeft":"","ArrowLeftCircle":"","ArrowLeftSmall":"","ArrowOutSquare":"","ArrowRight":"","ArrowRightCircle":"","ArrowRightSmall":"","ArrowUp":"","ArrowUpCircle":"","ArrowUpRight":"","ArrowUpRightSmall":"","ArrowUpSmall":"","ArrowsOut":"","ArtifactFile":"","Artifacts":"","Attachment":"","Batch":"","Book":"","BookText":"","Branch":"","Cache":"","Camera":"","Capacity":"","CaretDown":"","CaretDownSmall":"","CaretDownUp":"","CaretLeft":"","CaretLeftSmall":"","CaretRight":"","CaretRightSmall":"","CaretUp":"","CaretUpDown":"","CaretUpSmall":"","Chart":"","Chat":"","ChatAdd":"","ChatAddFilled":"","Chats":"","Check":"","CheckCircle":"","CheckCircleFilled":"","CheckDouble":"","Checklist":"","Claudification":"","Clipboard":"","Clock":"","Cloud":"","Code":"","CodeBlock":"","CodeBrackets":"","CoffeeCup":"","Collapse":"","CommandLine":"","Computer":"","Connectors":"","Copy":"","CreditCard":"","Database":"","DotsHorizontal":"","DotsHorizontalSmall":"","DotsVertical":"","DotsVerticalSmall":"","Download":"","Edit":"","Evals":"","Expand":"","Experimental":"","ExtendedThinking":"","Eye":"","EyeSlash":"","Feedback":"","File":"","Files":"","Filter":"","Folder":"","FolderPlus":"","Ghost":"","GhostFilled":"","Globe":"","GraduationCap":"","Hand":"","Help":"","Home":"","Image":"","Indent":"","Info":"","Interactive":"","Key":"","Keyboard":"","Knowledge":"","Library":"","Lightbulb":"","Lightning":"","Link":"","LinkSimple":"","ListAdd":"","ListBullet":"","ListNumbered":"","Lock":"","LockOpen":"","Logout":"","Mailbox":"","MapPin":"","Memory":"","Minus":"","MinusSmall":"","Moon":"","Notification":"","Organization":"","Owl":"","PaperPlane":"","Play":"","PlayCircle":"","PlayCircleFilled":"","PlaySmall":"","Pro":"","Prohibit":"","Projects":"","ProjectsX":"","Prompt":"","PullRequestClosed":"","PullRequestDraft":"","Reload":"","Research":"","Screenshare":"","Search":"","Settings":"","Share":"","Sidebar":"","SidebarClose":"","SidebarOpen":"","Signpost":"","Slides":"","Sort":"","Spreadsheet":"","Star":"","StarFilled":"","Stop":"","StopCircle":"","StopSmall":"","Styles":"","Sun":"","Tasks":"","Team":"","Temperature":"","TemperatureSimple":"","TextAa":"","TextBold":"","TextBoldSelected":"","TextItalics":"","TextItalicsSelected":"","TextUnderline":"","TextUnderlineSelected":"","ThumbsDown":"","ThumbsUp":"","Timer":"","Token":"","Tool":"","Trash":"","Trust":"","Upload":"","User":"","UserCircle":"","Users":"","Verified":"","Voice":"","Warning":"","Workspace":"","Wrench":"","X":"","XSmall":""}',
      );
      iconFontCss = "";
    });
  };
}
