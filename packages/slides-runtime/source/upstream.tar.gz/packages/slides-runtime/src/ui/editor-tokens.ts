/** Restored application module; prepare first, initialize in original order. */
import {
  bindRuntimeValue,
  type RuntimeBindings,
} from "../bindings";

declare module "../bindings" {
  interface RuntimeBindings {
    designTokens: DesignTokens;
    initializeUiEditorTokens: () => void;
  }
}

/** A design token resolved through a CSS custom property. */
export interface DesignToken {
  cssVar: string;
}

/** Shared shape of GitStateTokens. */
export interface GitStateTokens {
  added: DesignToken;
  removed: DesignToken;
  modified: DesignToken;
  merged: DesignToken;
  closed: DesignToken;
  conflicting: DesignToken;
  draft: DesignToken;
  opened: DesignToken;
  queued: DesignToken;
}

/** Shared shape of ColorScaleTokens. */
export interface ColorScaleTokens {
  0: DesignToken;
  10: DesignToken;
  20: DesignToken;
  30: DesignToken;
  40: DesignToken;
  50: DesignToken;
  60: DesignToken;
  70: DesignToken;
  80: DesignToken;
  90: DesignToken;
  100: DesignToken;
  150: DesignToken;
  200: DesignToken;
  250: DesignToken;
  300: DesignToken;
  350: DesignToken;
  400: DesignToken;
  450: DesignToken;
  500: DesignToken;
  550: DesignToken;
  600: DesignToken;
  650: DesignToken;
  700: DesignToken;
  750: DesignToken;
  800: DesignToken;
  810: DesignToken;
  820: DesignToken;
  830: DesignToken;
  840: DesignToken;
  850: DesignToken;
  860: DesignToken;
  870: DesignToken;
  880: DesignToken;
  890: DesignToken;
  900: DesignToken;
}

/** Shared shape of TextScaleTokens. */
export interface TextScaleTokens {
  caption: DesignToken;
  footnote: DesignToken;
  code: DesignToken;
  body: DesignToken;
  prose: DesignToken;
  heading: DesignToken;
  title: DesignToken;
}

/** Shared shape of ChartRampTokens. */
export interface ChartRampTokens {
  1: DesignToken;
  2: DesignToken;
  3: DesignToken;
  4: DesignToken;
  5: DesignToken;
  6: DesignToken;
  7: DesignToken;
}

/** Every design token the editor reads, keyed by group. */
export interface DesignTokens {
  radius: DesignToken;
  radiusComposer: DesignToken;
  h: {
    control: DesignToken & {
      nested: DesignToken;
    };
  };
  icon: DesignToken;
  pad: {
    xs: DesignToken;
    sm: DesignToken;
    md: DesignToken;
    lg: DesignToken;
    xl: DesignToken;
  };
  gap: {
    xs: DesignToken;
    sm: DesignToken;
    md: DesignToken;
    lg: DesignToken;
    xl: DesignToken;
  };
  outset: {
    x: DesignToken;
    y: DesignToken;
  };
  border: DesignToken & {
    accent: DesignToken;
    danger: DesignToken;
    success: DesignToken;
    warning: DesignToken;
    pro: DesignToken;
    editor: {
      comment: DesignToken & {
        target: DesignToken;
      };
    };
    git: GitStateTokens;
    strong: DesignToken;
    stronger: DesignToken;
  };
  shadow: {
    sm: DesignToken;
    md: DesignToken;
    lg: DesignToken;
    color: DesignToken;
    popover: DesignToken;
    drop: {
      ring: DesignToken & {
        danger: DesignToken;
      };
      glow: DesignToken & {
        danger: DesignToken;
      };
    };
  };
  ring: {
    outer: DesignToken;
    inner: DesignToken;
    color: DesignToken;
    hairline: DesignToken;
  };
  focus: {
    shadow: DesignToken & {
      danger: DesignToken;
    };
  };
  font: {
    mono: DesignToken & {
      ui: DesignToken;
    };
    system: DesignToken;
    sans: DesignToken & {
      display: DesignToken;
    };
    voice: DesignToken;
  };
  ease: {
    out: DesignToken;
    snap: DesignToken;
    overshoot: DesignToken;
  };
  dur: {
    fast: DesignToken;
    snap: DesignToken;
    base: DesignToken;
    sheet: DesignToken;
    slow: DesignToken;
  };
  btn: {
    spring: DesignToken;
  };
  black: DesignToken;
  oncolor: {
    200: DesignToken;
    300: DesignToken;
  };
  clay: DesignToken & {
    emphasized: DesignToken;
  };
  heather: DesignToken;
  plum: DesignToken;
  cactus: DesignToken;
  mineral: DesignToken;
  gray: ColorScaleTokens;
  red: ColorScaleTokens;
  orange: ColorScaleTokens;
  yellow: ColorScaleTokens;
  green: ColorScaleTokens;
  aqua: ColorScaleTokens;
  blue: ColorScaleTokens;
  violet: ColorScaleTokens;
  magenta: ColorScaleTokens;
  pictogram: {
    highlight: {
      default: DesignToken;
      heather: DesignToken;
      cactus: DesignToken;
    };
  };
  cursor: {
    interactive: DesignToken;
  };
  neutral: ColorScaleTokens;
  alpha: {
    0: DesignToken;
    1: DesignToken;
    2: DesignToken;
    3: DesignToken;
    4: DesignToken;
    5: DesignToken;
    6: DesignToken;
    7: DesignToken;
    8: DesignToken;
    9: DesignToken;
  };
  surface: {
    0: DesignToken;
    1: DesignToken;
    2: DesignToken;
    3: DesignToken;
    popover: DesignToken;
    panel: DesignToken;
  };
  page: {
    bg: DesignToken;
  };
  fill: {
    accent: DesignToken & {
      hover: DesignToken;
    };
    danger: DesignToken & {
      hover: DesignToken;
    };
    success: DesignToken & {
      hover: DesignToken;
    };
    warning: DesignToken & {
      hover: DesignToken;
    };
    pro: DesignToken & {
      hover: DesignToken;
    };
    git: {
      added: DesignToken & {
        hover: DesignToken;
      };
      removed: DesignToken & {
        hover: DesignToken;
      };
      modified: DesignToken & {
        hover: DesignToken;
      };
      merged: DesignToken & {
        hover: DesignToken;
      };
      closed: DesignToken & {
        hover: DesignToken;
      };
      conflicting: DesignToken & {
        hover: DesignToken;
      };
      draft: DesignToken & {
        hover: DesignToken;
      };
      opened: DesignToken & {
        hover: DesignToken;
      };
      queued: DesignToken & {
        hover: DesignToken;
      };
    };
    brand: DesignToken & {
      hover: DesignToken;
    };
    primary: DesignToken & {
      hover: DesignToken;
    };
    secondary: DesignToken & {
      hover: DesignToken;
      ring: DesignToken;
      pressed: {
        ring: DesignToken;
      };
    };
    field: DesignToken & {
      ring: DesignToken;
    };
    ghost: {
      hover: DesignToken;
      selected: DesignToken;
    };
    disabled: DesignToken;
    control: DesignToken & {
      hover: DesignToken;
    };
  };
  bg: {
    accent: DesignToken & {
      chip: DesignToken;
      muted: DesignToken;
    };
    danger: DesignToken & {
      chip: DesignToken;
    };
    success: DesignToken & {
      chip: DesignToken;
    };
    warning: DesignToken & {
      chip: DesignToken;
    };
    pro: DesignToken & {
      chip: DesignToken;
    };
    tint: {
      red: DesignToken & {
        opaque: DesignToken;
      };
      orange: DesignToken & {
        opaque: DesignToken;
      };
      yellow: DesignToken & {
        opaque: DesignToken;
      };
      green: DesignToken & {
        opaque: DesignToken;
      };
      aqua: DesignToken & {
        opaque: DesignToken;
      };
      blue: DesignToken & {
        opaque: DesignToken;
      };
      violet: DesignToken & {
        opaque: DesignToken;
      };
      magenta: DesignToken & {
        opaque: DesignToken;
      };
    };
    git: GitStateTokens;
    highlight: DesignToken;
    editor: {
      canvas: DesignToken;
      claude: {
        pending: DesignToken;
      };
      highlight: {
        yellow: DesignToken;
        green: DesignToken;
        blue: DesignToken;
        magenta: DesignToken;
        violet: DesignToken;
        gray: DesignToken;
      };
      collaborator: {
        1: DesignToken;
        2: DesignToken;
        3: DesignToken;
        4: DesignToken;
        5: DesignToken;
        6: DesignToken;
      };
      comment: DesignToken & {
        active: DesignToken;
      };
    };
    neutral: DesignToken & {
      hover: DesignToken;
      chip: DesignToken & {
        hover: DesignToken;
      };
    };
    user: {
      message: DesignToken;
    };
  };
  backdrop: DesignToken;
  text: {
    accent: DesignToken;
    danger: DesignToken;
    success: DesignToken;
    warning: DesignToken;
    pro: DesignToken;
    tint: {
      red: DesignToken;
      orange: DesignToken;
      yellow: DesignToken;
      green: DesignToken;
      aqua: DesignToken;
      blue: DesignToken;
      violet: DesignToken;
      magenta: DesignToken;
    };
    git: GitStateTokens;
    primary: DesignToken;
    secondary: DesignToken;
    muted: DesignToken;
    disabled: DesignToken;
  };
  fontSize: TextScaleTokens;
  fontWeight: {
    regular: DesignToken;
    medium: DesignToken;
    semibold: DesignToken;
    bold: DesignToken;
  };
  leading: TextScaleTokens;
  on: {
    primary: DesignToken;
    accent: DesignToken;
    danger: DesignToken;
    success: DesignToken;
    warning: DesignToken;
    pro: DesignToken;
    git: GitStateTokens;
    brand: DesignToken;
  };
  chart: {
    categorical: {
      1: DesignToken;
      2: DesignToken;
      3: DesignToken;
      4: DesignToken;
      5: DesignToken;
      6: DesignToken;
      7: DesignToken;
      8: DesignToken;
    };
    sequential: ChartRampTokens;
    diverging: ChartRampTokens;
    status: {
      good: DesignToken;
      warning: DesignToken;
      serious: DesignToken;
      critical: DesignToken;
    };
    muted: DesignToken;
    reference: DesignToken & {
      tint: DesignToken;
    };
    grid: DesignToken;
    axis: DesignToken;
    baseline: DesignToken;
  };
  editor: {
    collaborator: {
      [index: number]: DesignToken | undefined;
      1: DesignToken;
      2: DesignToken;
      3: DesignToken;
      4: DesignToken;
      5: DesignToken;
      6: DesignToken;
    };
  };
  opacity: {
    disabled: DesignToken;
    icon: {
      secondary: DesignToken;
    };
  };
  z: {
    modal: DesignToken;
    coachmark: DesignToken;
    popover: DesignToken;
    tooltip: DesignToken;
    toast: DesignToken;
  };
}

export function installUiEditorTokens(runtime: RuntimeBindings): () => void {
  var designTokens: DesignTokens;
  var initializeUiEditorTokens: () => void;

  bindRuntimeValue(
    runtime,
    "designTokens",
    () => designTokens,
    (value) => {
      designTokens = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "initializeUiEditorTokens",
    () => initializeUiEditorTokens,
    (value) => {
      initializeUiEditorTokens = value;
    },
  );
  return () => {
    initializeUiEditorTokens = (0, runtime.initializeOnce)(() => {
      designTokens = {
        radius: {
          cssVar: "var(--cds-radius)",
        },
        radiusComposer: {
          cssVar: "var(--cds-radius-composer)",
        },
        h: {
          control: {
            cssVar: "var(--cds-h-control)",
            nested: {
              cssVar: "var(--cds-h-control-nested)",
            },
          },
        },
        icon: {
          cssVar: "var(--cds-icon)",
        },
        pad: {
          xs: {
            cssVar: "var(--cds-pad-xs)",
          },
          sm: {
            cssVar: "var(--cds-pad-sm)",
          },
          md: {
            cssVar: "var(--cds-pad-md)",
          },
          lg: {
            cssVar: "var(--cds-pad-lg)",
          },
          xl: {
            cssVar: "var(--cds-pad-xl)",
          },
        },
        gap: {
          xs: {
            cssVar: "var(--cds-gap-xs)",
          },
          sm: {
            cssVar: "var(--cds-gap-sm)",
          },
          md: {
            cssVar: "var(--cds-gap-md)",
          },
          lg: {
            cssVar: "var(--cds-gap-lg)",
          },
          xl: {
            cssVar: "var(--cds-gap-xl)",
          },
        },
        outset: {
          x: {
            cssVar: "var(--cds-outset-x)",
          },
          y: {
            cssVar: "var(--cds-outset-y)",
          },
        },
        border: {
          cssVar: "var(--cds-border)",
          accent: {
            cssVar: "var(--cds-border-accent)",
          },
          danger: {
            cssVar: "var(--cds-border-danger)",
          },
          success: {
            cssVar: "var(--cds-border-success)",
          },
          warning: {
            cssVar: "var(--cds-border-warning)",
          },
          pro: {
            cssVar: "var(--cds-border-pro)",
          },
          editor: {
            comment: {
              cssVar: "var(--cds-border-editor-comment)",
              target: {
                cssVar: "var(--cds-border-editor-comment-target)",
              },
            },
          },
          git: {
            added: {
              cssVar: "var(--cds-border-git-added)",
            },
            removed: {
              cssVar: "var(--cds-border-git-removed)",
            },
            modified: {
              cssVar: "var(--cds-border-git-modified)",
            },
            merged: {
              cssVar: "var(--cds-border-git-merged)",
            },
            closed: {
              cssVar: "var(--cds-border-git-closed)",
            },
            conflicting: {
              cssVar: "var(--cds-border-git-conflicting)",
            },
            draft: {
              cssVar: "var(--cds-border-git-draft)",
            },
            opened: {
              cssVar: "var(--cds-border-git-opened)",
            },
            queued: {
              cssVar: "var(--cds-border-git-queued)",
            },
          },
          strong: {
            cssVar: "var(--cds-border-strong)",
          },
          stronger: {
            cssVar: "var(--cds-border-stronger)",
          },
        },
        shadow: {
          sm: {
            cssVar: "var(--cds-shadow-sm)",
          },
          md: {
            cssVar: "var(--cds-shadow-md)",
          },
          lg: {
            cssVar: "var(--cds-shadow-lg)",
          },
          color: {
            cssVar: "var(--cds-shadow-color)",
          },
          popover: {
            cssVar: "var(--cds-shadow-popover)",
          },
          drop: {
            ring: {
              cssVar: "var(--cds-shadow-drop-ring)",
              danger: {
                cssVar: "var(--cds-shadow-drop-ring-danger)",
              },
            },
            glow: {
              cssVar: "var(--cds-shadow-drop-glow)",
              danger: {
                cssVar: "var(--cds-shadow-drop-glow-danger)",
              },
            },
          },
        },
        ring: {
          outer: {
            cssVar: "var(--cds-ring-outer)",
          },
          inner: {
            cssVar: "var(--cds-ring-inner)",
          },
          color: {
            cssVar: "var(--cds-ring-color)",
          },
          hairline: {
            cssVar: "var(--cds-ring-hairline)",
          },
        },
        focus: {
          shadow: {
            cssVar: "var(--cds-focus-shadow)",
            danger: {
              cssVar: "var(--cds-focus-shadow-danger)",
            },
          },
        },
        font: {
          mono: {
            cssVar: "var(--cds-font-mono)",
            ui: {
              cssVar: "var(--cds-font-mono-ui)",
            },
          },
          system: {
            cssVar: "var(--cds-font-system)",
          },
          sans: {
            cssVar: "var(--cds-font-sans)",
            display: {
              cssVar: "var(--cds-font-sans-display)",
            },
          },
          voice: {
            cssVar: "var(--cds-font-voice)",
          },
        },
        ease: {
          out: {
            cssVar: "var(--cds-ease-out)",
          },
          snap: {
            cssVar: "var(--cds-ease-snap)",
          },
          overshoot: {
            cssVar: "var(--cds-ease-overshoot)",
          },
        },
        dur: {
          fast: {
            cssVar: "var(--cds-dur-fast)",
          },
          snap: {
            cssVar: "var(--cds-dur-snap)",
          },
          base: {
            cssVar: "var(--cds-dur-base)",
          },
          sheet: {
            cssVar: "var(--cds-dur-sheet)",
          },
          slow: {
            cssVar: "var(--cds-dur-slow)",
          },
        },
        btn: {
          spring: {
            cssVar: "var(--cds-btn-spring)",
          },
        },
        black: {
          cssVar: "var(--cds-black)",
        },
        oncolor: {
          200: {
            cssVar: "var(--cds-oncolor-200)",
          },
          300: {
            cssVar: "var(--cds-oncolor-300)",
          },
        },
        clay: {
          cssVar: "var(--cds-clay)",
          emphasized: {
            cssVar: "var(--cds-clay-emphasized)",
          },
        },
        heather: {
          cssVar: "var(--cds-heather)",
        },
        plum: {
          cssVar: "var(--cds-plum)",
        },
        cactus: {
          cssVar: "var(--cds-cactus)",
        },
        mineral: {
          cssVar: "var(--cds-mineral)",
        },
        gray: {
          0: {
            cssVar: "var(--cds-gray-0)",
          },
          10: {
            cssVar: "var(--cds-gray-10)",
          },
          20: {
            cssVar: "var(--cds-gray-20)",
          },
          30: {
            cssVar: "var(--cds-gray-30)",
          },
          40: {
            cssVar: "var(--cds-gray-40)",
          },
          50: {
            cssVar: "var(--cds-gray-50)",
          },
          60: {
            cssVar: "var(--cds-gray-60)",
          },
          70: {
            cssVar: "var(--cds-gray-70)",
          },
          80: {
            cssVar: "var(--cds-gray-80)",
          },
          90: {
            cssVar: "var(--cds-gray-90)",
          },
          100: {
            cssVar: "var(--cds-gray-100)",
          },
          150: {
            cssVar: "var(--cds-gray-150)",
          },
          200: {
            cssVar: "var(--cds-gray-200)",
          },
          250: {
            cssVar: "var(--cds-gray-250)",
          },
          300: {
            cssVar: "var(--cds-gray-300)",
          },
          350: {
            cssVar: "var(--cds-gray-350)",
          },
          400: {
            cssVar: "var(--cds-gray-400)",
          },
          450: {
            cssVar: "var(--cds-gray-450)",
          },
          500: {
            cssVar: "var(--cds-gray-500)",
          },
          550: {
            cssVar: "var(--cds-gray-550)",
          },
          600: {
            cssVar: "var(--cds-gray-600)",
          },
          650: {
            cssVar: "var(--cds-gray-650)",
          },
          700: {
            cssVar: "var(--cds-gray-700)",
          },
          750: {
            cssVar: "var(--cds-gray-750)",
          },
          800: {
            cssVar: "var(--cds-gray-800)",
          },
          810: {
            cssVar: "var(--cds-gray-810)",
          },
          820: {
            cssVar: "var(--cds-gray-820)",
          },
          830: {
            cssVar: "var(--cds-gray-830)",
          },
          840: {
            cssVar: "var(--cds-gray-840)",
          },
          850: {
            cssVar: "var(--cds-gray-850)",
          },
          860: {
            cssVar: "var(--cds-gray-860)",
          },
          870: {
            cssVar: "var(--cds-gray-870)",
          },
          880: {
            cssVar: "var(--cds-gray-880)",
          },
          890: {
            cssVar: "var(--cds-gray-890)",
          },
          900: {
            cssVar: "var(--cds-gray-900)",
          },
        },
        red: {
          0: {
            cssVar: "var(--cds-red-0)",
          },
          10: {
            cssVar: "var(--cds-red-10)",
          },
          20: {
            cssVar: "var(--cds-red-20)",
          },
          30: {
            cssVar: "var(--cds-red-30)",
          },
          40: {
            cssVar: "var(--cds-red-40)",
          },
          50: {
            cssVar: "var(--cds-red-50)",
          },
          60: {
            cssVar: "var(--cds-red-60)",
          },
          70: {
            cssVar: "var(--cds-red-70)",
          },
          80: {
            cssVar: "var(--cds-red-80)",
          },
          90: {
            cssVar: "var(--cds-red-90)",
          },
          100: {
            cssVar: "var(--cds-red-100)",
          },
          150: {
            cssVar: "var(--cds-red-150)",
          },
          200: {
            cssVar: "var(--cds-red-200)",
          },
          250: {
            cssVar: "var(--cds-red-250)",
          },
          300: {
            cssVar: "var(--cds-red-300)",
          },
          350: {
            cssVar: "var(--cds-red-350)",
          },
          400: {
            cssVar: "var(--cds-red-400)",
          },
          450: {
            cssVar: "var(--cds-red-450)",
          },
          500: {
            cssVar: "var(--cds-red-500)",
          },
          550: {
            cssVar: "var(--cds-red-550)",
          },
          600: {
            cssVar: "var(--cds-red-600)",
          },
          650: {
            cssVar: "var(--cds-red-650)",
          },
          700: {
            cssVar: "var(--cds-red-700)",
          },
          750: {
            cssVar: "var(--cds-red-750)",
          },
          800: {
            cssVar: "var(--cds-red-800)",
          },
          810: {
            cssVar: "var(--cds-red-810)",
          },
          820: {
            cssVar: "var(--cds-red-820)",
          },
          830: {
            cssVar: "var(--cds-red-830)",
          },
          840: {
            cssVar: "var(--cds-red-840)",
          },
          850: {
            cssVar: "var(--cds-red-850)",
          },
          860: {
            cssVar: "var(--cds-red-860)",
          },
          870: {
            cssVar: "var(--cds-red-870)",
          },
          880: {
            cssVar: "var(--cds-red-880)",
          },
          890: {
            cssVar: "var(--cds-red-890)",
          },
          900: {
            cssVar: "var(--cds-red-900)",
          },
        },
        orange: {
          0: {
            cssVar: "var(--cds-orange-0)",
          },
          10: {
            cssVar: "var(--cds-orange-10)",
          },
          20: {
            cssVar: "var(--cds-orange-20)",
          },
          30: {
            cssVar: "var(--cds-orange-30)",
          },
          40: {
            cssVar: "var(--cds-orange-40)",
          },
          50: {
            cssVar: "var(--cds-orange-50)",
          },
          60: {
            cssVar: "var(--cds-orange-60)",
          },
          70: {
            cssVar: "var(--cds-orange-70)",
          },
          80: {
            cssVar: "var(--cds-orange-80)",
          },
          90: {
            cssVar: "var(--cds-orange-90)",
          },
          100: {
            cssVar: "var(--cds-orange-100)",
          },
          150: {
            cssVar: "var(--cds-orange-150)",
          },
          200: {
            cssVar: "var(--cds-orange-200)",
          },
          250: {
            cssVar: "var(--cds-orange-250)",
          },
          300: {
            cssVar: "var(--cds-orange-300)",
          },
          350: {
            cssVar: "var(--cds-orange-350)",
          },
          400: {
            cssVar: "var(--cds-orange-400)",
          },
          450: {
            cssVar: "var(--cds-orange-450)",
          },
          500: {
            cssVar: "var(--cds-orange-500)",
          },
          550: {
            cssVar: "var(--cds-orange-550)",
          },
          600: {
            cssVar: "var(--cds-orange-600)",
          },
          650: {
            cssVar: "var(--cds-orange-650)",
          },
          700: {
            cssVar: "var(--cds-orange-700)",
          },
          750: {
            cssVar: "var(--cds-orange-750)",
          },
          800: {
            cssVar: "var(--cds-orange-800)",
          },
          810: {
            cssVar: "var(--cds-orange-810)",
          },
          820: {
            cssVar: "var(--cds-orange-820)",
          },
          830: {
            cssVar: "var(--cds-orange-830)",
          },
          840: {
            cssVar: "var(--cds-orange-840)",
          },
          850: {
            cssVar: "var(--cds-orange-850)",
          },
          860: {
            cssVar: "var(--cds-orange-860)",
          },
          870: {
            cssVar: "var(--cds-orange-870)",
          },
          880: {
            cssVar: "var(--cds-orange-880)",
          },
          890: {
            cssVar: "var(--cds-orange-890)",
          },
          900: {
            cssVar: "var(--cds-orange-900)",
          },
        },
        yellow: {
          0: {
            cssVar: "var(--cds-yellow-0)",
          },
          10: {
            cssVar: "var(--cds-yellow-10)",
          },
          20: {
            cssVar: "var(--cds-yellow-20)",
          },
          30: {
            cssVar: "var(--cds-yellow-30)",
          },
          40: {
            cssVar: "var(--cds-yellow-40)",
          },
          50: {
            cssVar: "var(--cds-yellow-50)",
          },
          60: {
            cssVar: "var(--cds-yellow-60)",
          },
          70: {
            cssVar: "var(--cds-yellow-70)",
          },
          80: {
            cssVar: "var(--cds-yellow-80)",
          },
          90: {
            cssVar: "var(--cds-yellow-90)",
          },
          100: {
            cssVar: "var(--cds-yellow-100)",
          },
          150: {
            cssVar: "var(--cds-yellow-150)",
          },
          200: {
            cssVar: "var(--cds-yellow-200)",
          },
          250: {
            cssVar: "var(--cds-yellow-250)",
          },
          300: {
            cssVar: "var(--cds-yellow-300)",
          },
          350: {
            cssVar: "var(--cds-yellow-350)",
          },
          400: {
            cssVar: "var(--cds-yellow-400)",
          },
          450: {
            cssVar: "var(--cds-yellow-450)",
          },
          500: {
            cssVar: "var(--cds-yellow-500)",
          },
          550: {
            cssVar: "var(--cds-yellow-550)",
          },
          600: {
            cssVar: "var(--cds-yellow-600)",
          },
          650: {
            cssVar: "var(--cds-yellow-650)",
          },
          700: {
            cssVar: "var(--cds-yellow-700)",
          },
          750: {
            cssVar: "var(--cds-yellow-750)",
          },
          800: {
            cssVar: "var(--cds-yellow-800)",
          },
          810: {
            cssVar: "var(--cds-yellow-810)",
          },
          820: {
            cssVar: "var(--cds-yellow-820)",
          },
          830: {
            cssVar: "var(--cds-yellow-830)",
          },
          840: {
            cssVar: "var(--cds-yellow-840)",
          },
          850: {
            cssVar: "var(--cds-yellow-850)",
          },
          860: {
            cssVar: "var(--cds-yellow-860)",
          },
          870: {
            cssVar: "var(--cds-yellow-870)",
          },
          880: {
            cssVar: "var(--cds-yellow-880)",
          },
          890: {
            cssVar: "var(--cds-yellow-890)",
          },
          900: {
            cssVar: "var(--cds-yellow-900)",
          },
        },
        green: {
          0: {
            cssVar: "var(--cds-green-0)",
          },
          10: {
            cssVar: "var(--cds-green-10)",
          },
          20: {
            cssVar: "var(--cds-green-20)",
          },
          30: {
            cssVar: "var(--cds-green-30)",
          },
          40: {
            cssVar: "var(--cds-green-40)",
          },
          50: {
            cssVar: "var(--cds-green-50)",
          },
          60: {
            cssVar: "var(--cds-green-60)",
          },
          70: {
            cssVar: "var(--cds-green-70)",
          },
          80: {
            cssVar: "var(--cds-green-80)",
          },
          90: {
            cssVar: "var(--cds-green-90)",
          },
          100: {
            cssVar: "var(--cds-green-100)",
          },
          150: {
            cssVar: "var(--cds-green-150)",
          },
          200: {
            cssVar: "var(--cds-green-200)",
          },
          250: {
            cssVar: "var(--cds-green-250)",
          },
          300: {
            cssVar: "var(--cds-green-300)",
          },
          350: {
            cssVar: "var(--cds-green-350)",
          },
          400: {
            cssVar: "var(--cds-green-400)",
          },
          450: {
            cssVar: "var(--cds-green-450)",
          },
          500: {
            cssVar: "var(--cds-green-500)",
          },
          550: {
            cssVar: "var(--cds-green-550)",
          },
          600: {
            cssVar: "var(--cds-green-600)",
          },
          650: {
            cssVar: "var(--cds-green-650)",
          },
          700: {
            cssVar: "var(--cds-green-700)",
          },
          750: {
            cssVar: "var(--cds-green-750)",
          },
          800: {
            cssVar: "var(--cds-green-800)",
          },
          810: {
            cssVar: "var(--cds-green-810)",
          },
          820: {
            cssVar: "var(--cds-green-820)",
          },
          830: {
            cssVar: "var(--cds-green-830)",
          },
          840: {
            cssVar: "var(--cds-green-840)",
          },
          850: {
            cssVar: "var(--cds-green-850)",
          },
          860: {
            cssVar: "var(--cds-green-860)",
          },
          870: {
            cssVar: "var(--cds-green-870)",
          },
          880: {
            cssVar: "var(--cds-green-880)",
          },
          890: {
            cssVar: "var(--cds-green-890)",
          },
          900: {
            cssVar: "var(--cds-green-900)",
          },
        },
        aqua: {
          0: {
            cssVar: "var(--cds-aqua-0)",
          },
          10: {
            cssVar: "var(--cds-aqua-10)",
          },
          20: {
            cssVar: "var(--cds-aqua-20)",
          },
          30: {
            cssVar: "var(--cds-aqua-30)",
          },
          40: {
            cssVar: "var(--cds-aqua-40)",
          },
          50: {
            cssVar: "var(--cds-aqua-50)",
          },
          60: {
            cssVar: "var(--cds-aqua-60)",
          },
          70: {
            cssVar: "var(--cds-aqua-70)",
          },
          80: {
            cssVar: "var(--cds-aqua-80)",
          },
          90: {
            cssVar: "var(--cds-aqua-90)",
          },
          100: {
            cssVar: "var(--cds-aqua-100)",
          },
          150: {
            cssVar: "var(--cds-aqua-150)",
          },
          200: {
            cssVar: "var(--cds-aqua-200)",
          },
          250: {
            cssVar: "var(--cds-aqua-250)",
          },
          300: {
            cssVar: "var(--cds-aqua-300)",
          },
          350: {
            cssVar: "var(--cds-aqua-350)",
          },
          400: {
            cssVar: "var(--cds-aqua-400)",
          },
          450: {
            cssVar: "var(--cds-aqua-450)",
          },
          500: {
            cssVar: "var(--cds-aqua-500)",
          },
          550: {
            cssVar: "var(--cds-aqua-550)",
          },
          600: {
            cssVar: "var(--cds-aqua-600)",
          },
          650: {
            cssVar: "var(--cds-aqua-650)",
          },
          700: {
            cssVar: "var(--cds-aqua-700)",
          },
          750: {
            cssVar: "var(--cds-aqua-750)",
          },
          800: {
            cssVar: "var(--cds-aqua-800)",
          },
          810: {
            cssVar: "var(--cds-aqua-810)",
          },
          820: {
            cssVar: "var(--cds-aqua-820)",
          },
          830: {
            cssVar: "var(--cds-aqua-830)",
          },
          840: {
            cssVar: "var(--cds-aqua-840)",
          },
          850: {
            cssVar: "var(--cds-aqua-850)",
          },
          860: {
            cssVar: "var(--cds-aqua-860)",
          },
          870: {
            cssVar: "var(--cds-aqua-870)",
          },
          880: {
            cssVar: "var(--cds-aqua-880)",
          },
          890: {
            cssVar: "var(--cds-aqua-890)",
          },
          900: {
            cssVar: "var(--cds-aqua-900)",
          },
        },
        blue: {
          0: {
            cssVar: "var(--cds-blue-0)",
          },
          10: {
            cssVar: "var(--cds-blue-10)",
          },
          20: {
            cssVar: "var(--cds-blue-20)",
          },
          30: {
            cssVar: "var(--cds-blue-30)",
          },
          40: {
            cssVar: "var(--cds-blue-40)",
          },
          50: {
            cssVar: "var(--cds-blue-50)",
          },
          60: {
            cssVar: "var(--cds-blue-60)",
          },
          70: {
            cssVar: "var(--cds-blue-70)",
          },
          80: {
            cssVar: "var(--cds-blue-80)",
          },
          90: {
            cssVar: "var(--cds-blue-90)",
          },
          100: {
            cssVar: "var(--cds-blue-100)",
          },
          150: {
            cssVar: "var(--cds-blue-150)",
          },
          200: {
            cssVar: "var(--cds-blue-200)",
          },
          250: {
            cssVar: "var(--cds-blue-250)",
          },
          300: {
            cssVar: "var(--cds-blue-300)",
          },
          350: {
            cssVar: "var(--cds-blue-350)",
          },
          400: {
            cssVar: "var(--cds-blue-400)",
          },
          450: {
            cssVar: "var(--cds-blue-450)",
          },
          500: {
            cssVar: "var(--cds-blue-500)",
          },
          550: {
            cssVar: "var(--cds-blue-550)",
          },
          600: {
            cssVar: "var(--cds-blue-600)",
          },
          650: {
            cssVar: "var(--cds-blue-650)",
          },
          700: {
            cssVar: "var(--cds-blue-700)",
          },
          750: {
            cssVar: "var(--cds-blue-750)",
          },
          800: {
            cssVar: "var(--cds-blue-800)",
          },
          810: {
            cssVar: "var(--cds-blue-810)",
          },
          820: {
            cssVar: "var(--cds-blue-820)",
          },
          830: {
            cssVar: "var(--cds-blue-830)",
          },
          840: {
            cssVar: "var(--cds-blue-840)",
          },
          850: {
            cssVar: "var(--cds-blue-850)",
          },
          860: {
            cssVar: "var(--cds-blue-860)",
          },
          870: {
            cssVar: "var(--cds-blue-870)",
          },
          880: {
            cssVar: "var(--cds-blue-880)",
          },
          890: {
            cssVar: "var(--cds-blue-890)",
          },
          900: {
            cssVar: "var(--cds-blue-900)",
          },
        },
        violet: {
          0: {
            cssVar: "var(--cds-violet-0)",
          },
          10: {
            cssVar: "var(--cds-violet-10)",
          },
          20: {
            cssVar: "var(--cds-violet-20)",
          },
          30: {
            cssVar: "var(--cds-violet-30)",
          },
          40: {
            cssVar: "var(--cds-violet-40)",
          },
          50: {
            cssVar: "var(--cds-violet-50)",
          },
          60: {
            cssVar: "var(--cds-violet-60)",
          },
          70: {
            cssVar: "var(--cds-violet-70)",
          },
          80: {
            cssVar: "var(--cds-violet-80)",
          },
          90: {
            cssVar: "var(--cds-violet-90)",
          },
          100: {
            cssVar: "var(--cds-violet-100)",
          },
          150: {
            cssVar: "var(--cds-violet-150)",
          },
          200: {
            cssVar: "var(--cds-violet-200)",
          },
          250: {
            cssVar: "var(--cds-violet-250)",
          },
          300: {
            cssVar: "var(--cds-violet-300)",
          },
          350: {
            cssVar: "var(--cds-violet-350)",
          },
          400: {
            cssVar: "var(--cds-violet-400)",
          },
          450: {
            cssVar: "var(--cds-violet-450)",
          },
          500: {
            cssVar: "var(--cds-violet-500)",
          },
          550: {
            cssVar: "var(--cds-violet-550)",
          },
          600: {
            cssVar: "var(--cds-violet-600)",
          },
          650: {
            cssVar: "var(--cds-violet-650)",
          },
          700: {
            cssVar: "var(--cds-violet-700)",
          },
          750: {
            cssVar: "var(--cds-violet-750)",
          },
          800: {
            cssVar: "var(--cds-violet-800)",
          },
          810: {
            cssVar: "var(--cds-violet-810)",
          },
          820: {
            cssVar: "var(--cds-violet-820)",
          },
          830: {
            cssVar: "var(--cds-violet-830)",
          },
          840: {
            cssVar: "var(--cds-violet-840)",
          },
          850: {
            cssVar: "var(--cds-violet-850)",
          },
          860: {
            cssVar: "var(--cds-violet-860)",
          },
          870: {
            cssVar: "var(--cds-violet-870)",
          },
          880: {
            cssVar: "var(--cds-violet-880)",
          },
          890: {
            cssVar: "var(--cds-violet-890)",
          },
          900: {
            cssVar: "var(--cds-violet-900)",
          },
        },
        magenta: {
          0: {
            cssVar: "var(--cds-magenta-0)",
          },
          10: {
            cssVar: "var(--cds-magenta-10)",
          },
          20: {
            cssVar: "var(--cds-magenta-20)",
          },
          30: {
            cssVar: "var(--cds-magenta-30)",
          },
          40: {
            cssVar: "var(--cds-magenta-40)",
          },
          50: {
            cssVar: "var(--cds-magenta-50)",
          },
          60: {
            cssVar: "var(--cds-magenta-60)",
          },
          70: {
            cssVar: "var(--cds-magenta-70)",
          },
          80: {
            cssVar: "var(--cds-magenta-80)",
          },
          90: {
            cssVar: "var(--cds-magenta-90)",
          },
          100: {
            cssVar: "var(--cds-magenta-100)",
          },
          150: {
            cssVar: "var(--cds-magenta-150)",
          },
          200: {
            cssVar: "var(--cds-magenta-200)",
          },
          250: {
            cssVar: "var(--cds-magenta-250)",
          },
          300: {
            cssVar: "var(--cds-magenta-300)",
          },
          350: {
            cssVar: "var(--cds-magenta-350)",
          },
          400: {
            cssVar: "var(--cds-magenta-400)",
          },
          450: {
            cssVar: "var(--cds-magenta-450)",
          },
          500: {
            cssVar: "var(--cds-magenta-500)",
          },
          550: {
            cssVar: "var(--cds-magenta-550)",
          },
          600: {
            cssVar: "var(--cds-magenta-600)",
          },
          650: {
            cssVar: "var(--cds-magenta-650)",
          },
          700: {
            cssVar: "var(--cds-magenta-700)",
          },
          750: {
            cssVar: "var(--cds-magenta-750)",
          },
          800: {
            cssVar: "var(--cds-magenta-800)",
          },
          810: {
            cssVar: "var(--cds-magenta-810)",
          },
          820: {
            cssVar: "var(--cds-magenta-820)",
          },
          830: {
            cssVar: "var(--cds-magenta-830)",
          },
          840: {
            cssVar: "var(--cds-magenta-840)",
          },
          850: {
            cssVar: "var(--cds-magenta-850)",
          },
          860: {
            cssVar: "var(--cds-magenta-860)",
          },
          870: {
            cssVar: "var(--cds-magenta-870)",
          },
          880: {
            cssVar: "var(--cds-magenta-880)",
          },
          890: {
            cssVar: "var(--cds-magenta-890)",
          },
          900: {
            cssVar: "var(--cds-magenta-900)",
          },
        },
        pictogram: {
          highlight: {
            default: {
              cssVar: "var(--cds-pictogram-highlight-default)",
            },
            heather: {
              cssVar: "var(--cds-pictogram-highlight-heather)",
            },
            cactus: {
              cssVar: "var(--cds-pictogram-highlight-cactus)",
            },
          },
        },
        cursor: {
          interactive: {
            cssVar: "var(--cds-cursor-interactive)",
          },
        },
        neutral: {
          0: {
            cssVar: "var(--cds-neutral-0)",
          },
          10: {
            cssVar: "var(--cds-neutral-10)",
          },
          20: {
            cssVar: "var(--cds-neutral-20)",
          },
          30: {
            cssVar: "var(--cds-neutral-30)",
          },
          40: {
            cssVar: "var(--cds-neutral-40)",
          },
          50: {
            cssVar: "var(--cds-neutral-50)",
          },
          60: {
            cssVar: "var(--cds-neutral-60)",
          },
          70: {
            cssVar: "var(--cds-neutral-70)",
          },
          80: {
            cssVar: "var(--cds-neutral-80)",
          },
          90: {
            cssVar: "var(--cds-neutral-90)",
          },
          100: {
            cssVar: "var(--cds-neutral-100)",
          },
          150: {
            cssVar: "var(--cds-neutral-150)",
          },
          200: {
            cssVar: "var(--cds-neutral-200)",
          },
          250: {
            cssVar: "var(--cds-neutral-250)",
          },
          300: {
            cssVar: "var(--cds-neutral-300)",
          },
          350: {
            cssVar: "var(--cds-neutral-350)",
          },
          400: {
            cssVar: "var(--cds-neutral-400)",
          },
          450: {
            cssVar: "var(--cds-neutral-450)",
          },
          500: {
            cssVar: "var(--cds-neutral-500)",
          },
          550: {
            cssVar: "var(--cds-neutral-550)",
          },
          600: {
            cssVar: "var(--cds-neutral-600)",
          },
          650: {
            cssVar: "var(--cds-neutral-650)",
          },
          700: {
            cssVar: "var(--cds-neutral-700)",
          },
          750: {
            cssVar: "var(--cds-neutral-750)",
          },
          800: {
            cssVar: "var(--cds-neutral-800)",
          },
          810: {
            cssVar: "var(--cds-neutral-810)",
          },
          820: {
            cssVar: "var(--cds-neutral-820)",
          },
          830: {
            cssVar: "var(--cds-neutral-830)",
          },
          840: {
            cssVar: "var(--cds-neutral-840)",
          },
          850: {
            cssVar: "var(--cds-neutral-850)",
          },
          860: {
            cssVar: "var(--cds-neutral-860)",
          },
          870: {
            cssVar: "var(--cds-neutral-870)",
          },
          880: {
            cssVar: "var(--cds-neutral-880)",
          },
          890: {
            cssVar: "var(--cds-neutral-890)",
          },
          900: {
            cssVar: "var(--cds-neutral-900)",
          },
        },
        alpha: {
          0: {
            cssVar: "var(--cds-alpha-0)",
          },
          1: {
            cssVar: "var(--cds-alpha-1)",
          },
          2: {
            cssVar: "var(--cds-alpha-2)",
          },
          3: {
            cssVar: "var(--cds-alpha-3)",
          },
          4: {
            cssVar: "var(--cds-alpha-4)",
          },
          5: {
            cssVar: "var(--cds-alpha-5)",
          },
          6: {
            cssVar: "var(--cds-alpha-6)",
          },
          7: {
            cssVar: "var(--cds-alpha-7)",
          },
          8: {
            cssVar: "var(--cds-alpha-8)",
          },
          9: {
            cssVar: "var(--cds-alpha-9)",
          },
        },
        surface: {
          0: {
            cssVar: "var(--cds-surface-0)",
          },
          1: {
            cssVar: "var(--cds-surface-1)",
          },
          2: {
            cssVar: "var(--cds-surface-2)",
          },
          3: {
            cssVar: "var(--cds-surface-3)",
          },
          popover: {
            cssVar: "var(--cds-surface-popover)",
          },
          panel: {
            cssVar: "var(--cds-surface-panel)",
          },
        },
        page: {
          bg: {
            cssVar: "var(--cds-page-bg)",
          },
        },
        fill: {
          accent: {
            cssVar: "var(--cds-fill-accent)",
            hover: {
              cssVar: "var(--cds-fill-accent-hover)",
            },
          },
          danger: {
            cssVar: "var(--cds-fill-danger)",
            hover: {
              cssVar: "var(--cds-fill-danger-hover)",
            },
          },
          success: {
            cssVar: "var(--cds-fill-success)",
            hover: {
              cssVar: "var(--cds-fill-success-hover)",
            },
          },
          warning: {
            cssVar: "var(--cds-fill-warning)",
            hover: {
              cssVar: "var(--cds-fill-warning-hover)",
            },
          },
          pro: {
            cssVar: "var(--cds-fill-pro)",
            hover: {
              cssVar: "var(--cds-fill-pro-hover)",
            },
          },
          git: {
            added: {
              cssVar: "var(--cds-fill-git-added)",
              hover: {
                cssVar: "var(--cds-fill-git-added-hover)",
              },
            },
            removed: {
              cssVar: "var(--cds-fill-git-removed)",
              hover: {
                cssVar: "var(--cds-fill-git-removed-hover)",
              },
            },
            modified: {
              cssVar: "var(--cds-fill-git-modified)",
              hover: {
                cssVar: "var(--cds-fill-git-modified-hover)",
              },
            },
            merged: {
              cssVar: "var(--cds-fill-git-merged)",
              hover: {
                cssVar: "var(--cds-fill-git-merged-hover)",
              },
            },
            closed: {
              cssVar: "var(--cds-fill-git-closed)",
              hover: {
                cssVar: "var(--cds-fill-git-closed-hover)",
              },
            },
            conflicting: {
              cssVar: "var(--cds-fill-git-conflicting)",
              hover: {
                cssVar: "var(--cds-fill-git-conflicting-hover)",
              },
            },
            draft: {
              cssVar: "var(--cds-fill-git-draft)",
              hover: {
                cssVar: "var(--cds-fill-git-draft-hover)",
              },
            },
            opened: {
              cssVar: "var(--cds-fill-git-opened)",
              hover: {
                cssVar: "var(--cds-fill-git-opened-hover)",
              },
            },
            queued: {
              cssVar: "var(--cds-fill-git-queued)",
              hover: {
                cssVar: "var(--cds-fill-git-queued-hover)",
              },
            },
          },
          brand: {
            cssVar: "var(--cds-fill-brand)",
            hover: {
              cssVar: "var(--cds-fill-brand-hover)",
            },
          },
          primary: {
            cssVar: "var(--cds-fill-primary)",
            hover: {
              cssVar: "var(--cds-fill-primary-hover)",
            },
          },
          secondary: {
            cssVar: "var(--cds-fill-secondary)",
            hover: {
              cssVar: "var(--cds-fill-secondary-hover)",
            },
            ring: {
              cssVar: "var(--cds-fill-secondary-ring)",
            },
            pressed: {
              ring: {
                cssVar: "var(--cds-fill-secondary-pressed-ring)",
              },
            },
          },
          field: {
            cssVar: "var(--cds-fill-field)",
            ring: {
              cssVar: "var(--cds-fill-field-ring)",
            },
          },
          ghost: {
            hover: {
              cssVar: "var(--cds-fill-ghost-hover)",
            },
            selected: {
              cssVar: "var(--cds-fill-ghost-selected)",
            },
          },
          disabled: {
            cssVar: "var(--cds-fill-disabled)",
          },
          control: {
            cssVar: "var(--cds-fill-control)",
            hover: {
              cssVar: "var(--cds-fill-control-hover)",
            },
          },
        },
        bg: {
          accent: {
            cssVar: "var(--cds-bg-accent)",
            chip: {
              cssVar: "var(--cds-bg-accent-chip)",
            },
            muted: {
              cssVar: "var(--cds-bg-accent-muted)",
            },
          },
          danger: {
            cssVar: "var(--cds-bg-danger)",
            chip: {
              cssVar: "var(--cds-bg-danger-chip)",
            },
          },
          success: {
            cssVar: "var(--cds-bg-success)",
            chip: {
              cssVar: "var(--cds-bg-success-chip)",
            },
          },
          warning: {
            cssVar: "var(--cds-bg-warning)",
            chip: {
              cssVar: "var(--cds-bg-warning-chip)",
            },
          },
          pro: {
            cssVar: "var(--cds-bg-pro)",
            chip: {
              cssVar: "var(--cds-bg-pro-chip)",
            },
          },
          tint: {
            red: {
              cssVar: "var(--cds-bg-tint-red)",
              opaque: {
                cssVar: "var(--cds-bg-tint-red-opaque)",
              },
            },
            orange: {
              cssVar: "var(--cds-bg-tint-orange)",
              opaque: {
                cssVar: "var(--cds-bg-tint-orange-opaque)",
              },
            },
            yellow: {
              cssVar: "var(--cds-bg-tint-yellow)",
              opaque: {
                cssVar: "var(--cds-bg-tint-yellow-opaque)",
              },
            },
            green: {
              cssVar: "var(--cds-bg-tint-green)",
              opaque: {
                cssVar: "var(--cds-bg-tint-green-opaque)",
              },
            },
            aqua: {
              cssVar: "var(--cds-bg-tint-aqua)",
              opaque: {
                cssVar: "var(--cds-bg-tint-aqua-opaque)",
              },
            },
            blue: {
              cssVar: "var(--cds-bg-tint-blue)",
              opaque: {
                cssVar: "var(--cds-bg-tint-blue-opaque)",
              },
            },
            violet: {
              cssVar: "var(--cds-bg-tint-violet)",
              opaque: {
                cssVar: "var(--cds-bg-tint-violet-opaque)",
              },
            },
            magenta: {
              cssVar: "var(--cds-bg-tint-magenta)",
              opaque: {
                cssVar: "var(--cds-bg-tint-magenta-opaque)",
              },
            },
          },
          git: {
            added: {
              cssVar: "var(--cds-bg-git-added)",
            },
            removed: {
              cssVar: "var(--cds-bg-git-removed)",
            },
            modified: {
              cssVar: "var(--cds-bg-git-modified)",
            },
            merged: {
              cssVar: "var(--cds-bg-git-merged)",
            },
            closed: {
              cssVar: "var(--cds-bg-git-closed)",
            },
            conflicting: {
              cssVar: "var(--cds-bg-git-conflicting)",
            },
            draft: {
              cssVar: "var(--cds-bg-git-draft)",
            },
            opened: {
              cssVar: "var(--cds-bg-git-opened)",
            },
            queued: {
              cssVar: "var(--cds-bg-git-queued)",
            },
          },
          highlight: {
            cssVar: "var(--cds-bg-highlight)",
          },
          editor: {
            canvas: {
              cssVar: "var(--cds-bg-editor-canvas)",
            },
            claude: {
              pending: {
                cssVar: "var(--cds-bg-editor-claude-pending)",
              },
            },
            highlight: {
              yellow: {
                cssVar: "var(--cds-bg-editor-highlight-yellow)",
              },
              green: {
                cssVar: "var(--cds-bg-editor-highlight-green)",
              },
              blue: {
                cssVar: "var(--cds-bg-editor-highlight-blue)",
              },
              magenta: {
                cssVar: "var(--cds-bg-editor-highlight-magenta)",
              },
              violet: {
                cssVar: "var(--cds-bg-editor-highlight-violet)",
              },
              gray: {
                cssVar: "var(--cds-bg-editor-highlight-gray)",
              },
            },
            collaborator: {
              1: {
                cssVar: "var(--cds-bg-editor-collaborator-1)",
              },
              2: {
                cssVar: "var(--cds-bg-editor-collaborator-2)",
              },
              3: {
                cssVar: "var(--cds-bg-editor-collaborator-3)",
              },
              4: {
                cssVar: "var(--cds-bg-editor-collaborator-4)",
              },
              5: {
                cssVar: "var(--cds-bg-editor-collaborator-5)",
              },
              6: {
                cssVar: "var(--cds-bg-editor-collaborator-6)",
              },
            },
            comment: {
              cssVar: "var(--cds-bg-editor-comment)",
              active: {
                cssVar: "var(--cds-bg-editor-comment-active)",
              },
            },
          },
          neutral: {
            cssVar: "var(--cds-bg-neutral)",
            hover: {
              cssVar: "var(--cds-bg-neutral-hover)",
            },
            chip: {
              cssVar: "var(--cds-bg-neutral-chip)",
              hover: {
                cssVar: "var(--cds-bg-neutral-chip-hover)",
              },
            },
          },
          user: {
            message: {
              cssVar: "var(--cds-bg-user-message)",
            },
          },
        },
        backdrop: {
          cssVar: "var(--cds-backdrop)",
        },
        text: {
          accent: {
            cssVar: "var(--cds-text-accent)",
          },
          danger: {
            cssVar: "var(--cds-text-danger)",
          },
          success: {
            cssVar: "var(--cds-text-success)",
          },
          warning: {
            cssVar: "var(--cds-text-warning)",
          },
          pro: {
            cssVar: "var(--cds-text-pro)",
          },
          tint: {
            red: {
              cssVar: "var(--cds-text-tint-red)",
            },
            orange: {
              cssVar: "var(--cds-text-tint-orange)",
            },
            yellow: {
              cssVar: "var(--cds-text-tint-yellow)",
            },
            green: {
              cssVar: "var(--cds-text-tint-green)",
            },
            aqua: {
              cssVar: "var(--cds-text-tint-aqua)",
            },
            blue: {
              cssVar: "var(--cds-text-tint-blue)",
            },
            violet: {
              cssVar: "var(--cds-text-tint-violet)",
            },
            magenta: {
              cssVar: "var(--cds-text-tint-magenta)",
            },
          },
          git: {
            added: {
              cssVar: "var(--cds-text-git-added)",
            },
            removed: {
              cssVar: "var(--cds-text-git-removed)",
            },
            modified: {
              cssVar: "var(--cds-text-git-modified)",
            },
            merged: {
              cssVar: "var(--cds-text-git-merged)",
            },
            closed: {
              cssVar: "var(--cds-text-git-closed)",
            },
            conflicting: {
              cssVar: "var(--cds-text-git-conflicting)",
            },
            draft: {
              cssVar: "var(--cds-text-git-draft)",
            },
            opened: {
              cssVar: "var(--cds-text-git-opened)",
            },
            queued: {
              cssVar: "var(--cds-text-git-queued)",
            },
          },
          primary: {
            cssVar: "var(--cds-text-primary)",
          },
          secondary: {
            cssVar: "var(--cds-text-secondary)",
          },
          muted: {
            cssVar: "var(--cds-text-muted)",
          },
          disabled: {
            cssVar: "var(--cds-text-disabled)",
          },
        },
        fontSize: {
          caption: {
            cssVar: "var(--cds-font-size-caption)",
          },
          footnote: {
            cssVar: "var(--cds-font-size-footnote)",
          },
          code: {
            cssVar: "var(--cds-font-size-code)",
          },
          body: {
            cssVar: "var(--cds-font-size-body)",
          },
          prose: {
            cssVar: "var(--cds-font-size-prose)",
          },
          heading: {
            cssVar: "var(--cds-font-size-heading)",
          },
          title: {
            cssVar: "var(--cds-font-size-title)",
          },
        },
        fontWeight: {
          regular: {
            cssVar: "var(--cds-font-weight-regular)",
          },
          medium: {
            cssVar: "var(--cds-font-weight-medium)",
          },
          semibold: {
            cssVar: "var(--cds-font-weight-semibold)",
          },
          bold: {
            cssVar: "var(--cds-font-weight-bold)",
          },
        },
        leading: {
          caption: {
            cssVar: "var(--cds-leading-caption)",
          },
          footnote: {
            cssVar: "var(--cds-leading-footnote)",
          },
          code: {
            cssVar: "var(--cds-leading-code)",
          },
          body: {
            cssVar: "var(--cds-leading-body)",
          },
          prose: {
            cssVar: "var(--cds-leading-prose)",
          },
          heading: {
            cssVar: "var(--cds-leading-heading)",
          },
          title: {
            cssVar: "var(--cds-leading-title)",
          },
        },
        on: {
          primary: {
            cssVar: "var(--cds-on-primary)",
          },
          accent: {
            cssVar: "var(--cds-on-accent)",
          },
          danger: {
            cssVar: "var(--cds-on-danger)",
          },
          success: {
            cssVar: "var(--cds-on-success)",
          },
          warning: {
            cssVar: "var(--cds-on-warning)",
          },
          pro: {
            cssVar: "var(--cds-on-pro)",
          },
          git: {
            added: {
              cssVar: "var(--cds-on-git-added)",
            },
            removed: {
              cssVar: "var(--cds-on-git-removed)",
            },
            modified: {
              cssVar: "var(--cds-on-git-modified)",
            },
            merged: {
              cssVar: "var(--cds-on-git-merged)",
            },
            closed: {
              cssVar: "var(--cds-on-git-closed)",
            },
            conflicting: {
              cssVar: "var(--cds-on-git-conflicting)",
            },
            draft: {
              cssVar: "var(--cds-on-git-draft)",
            },
            opened: {
              cssVar: "var(--cds-on-git-opened)",
            },
            queued: {
              cssVar: "var(--cds-on-git-queued)",
            },
          },
          brand: {
            cssVar: "var(--cds-on-brand)",
          },
        },
        chart: {
          categorical: {
            1: {
              cssVar: "var(--cds-chart-categorical-1)",
            },
            2: {
              cssVar: "var(--cds-chart-categorical-2)",
            },
            3: {
              cssVar: "var(--cds-chart-categorical-3)",
            },
            4: {
              cssVar: "var(--cds-chart-categorical-4)",
            },
            5: {
              cssVar: "var(--cds-chart-categorical-5)",
            },
            6: {
              cssVar: "var(--cds-chart-categorical-6)",
            },
            7: {
              cssVar: "var(--cds-chart-categorical-7)",
            },
            8: {
              cssVar: "var(--cds-chart-categorical-8)",
            },
          },
          sequential: {
            1: {
              cssVar: "var(--cds-chart-sequential-1)",
            },
            2: {
              cssVar: "var(--cds-chart-sequential-2)",
            },
            3: {
              cssVar: "var(--cds-chart-sequential-3)",
            },
            4: {
              cssVar: "var(--cds-chart-sequential-4)",
            },
            5: {
              cssVar: "var(--cds-chart-sequential-5)",
            },
            6: {
              cssVar: "var(--cds-chart-sequential-6)",
            },
            7: {
              cssVar: "var(--cds-chart-sequential-7)",
            },
          },
          diverging: {
            1: {
              cssVar: "var(--cds-chart-diverging-1)",
            },
            2: {
              cssVar: "var(--cds-chart-diverging-2)",
            },
            3: {
              cssVar: "var(--cds-chart-diverging-3)",
            },
            4: {
              cssVar: "var(--cds-chart-diverging-4)",
            },
            5: {
              cssVar: "var(--cds-chart-diverging-5)",
            },
            6: {
              cssVar: "var(--cds-chart-diverging-6)",
            },
            7: {
              cssVar: "var(--cds-chart-diverging-7)",
            },
          },
          status: {
            good: {
              cssVar: "var(--cds-chart-status-good)",
            },
            warning: {
              cssVar: "var(--cds-chart-status-warning)",
            },
            serious: {
              cssVar: "var(--cds-chart-status-serious)",
            },
            critical: {
              cssVar: "var(--cds-chart-status-critical)",
            },
          },
          muted: {
            cssVar: "var(--cds-chart-muted)",
          },
          reference: {
            cssVar: "var(--cds-chart-reference)",
            tint: {
              cssVar: "var(--cds-chart-reference-tint)",
            },
          },
          grid: {
            cssVar: "var(--cds-chart-grid)",
          },
          axis: {
            cssVar: "var(--cds-chart-axis)",
          },
          baseline: {
            cssVar: "var(--cds-chart-baseline)",
          },
        },
        editor: {
          collaborator: {
            1: {
              cssVar: "var(--cds-editor-collaborator-1)",
            },
            2: {
              cssVar: "var(--cds-editor-collaborator-2)",
            },
            3: {
              cssVar: "var(--cds-editor-collaborator-3)",
            },
            4: {
              cssVar: "var(--cds-editor-collaborator-4)",
            },
            5: {
              cssVar: "var(--cds-editor-collaborator-5)",
            },
            6: {
              cssVar: "var(--cds-editor-collaborator-6)",
            },
          },
        },
        opacity: {
          disabled: {
            cssVar: "var(--cds-opacity-disabled)",
          },
          icon: {
            secondary: {
              cssVar: "var(--cds-opacity-icon-secondary)",
            },
          },
        },
        z: {
          modal: {
            cssVar: "var(--cds-z-modal)",
          },
          coachmark: {
            cssVar: "var(--cds-z-coachmark)",
          },
          popover: {
            cssVar: "var(--cds-z-popover)",
          },
          tooltip: {
            cssVar: "var(--cds-z-tooltip)",
          },
          toast: {
            cssVar: "var(--cds-z-toast)",
          },
        },
      };
    });
  };
}
