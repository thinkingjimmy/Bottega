import type * as React from "react";
/** Restored application module; prepare first, initialize in original order. */
import {
  bindRuntimeValue,
  type Dynamic,
  type RuntimeBindings,
} from "../../runtime-types";
export function installCdsPlatformRootFontSize(
  runtime: RuntimeBindings,
): () => void {
  var reactPlatformRootFontSize: Dynamic;
  var jsxPlatformRootFontSize: Dynamic;
  var SkeletonDecorativeContext: Dynamic;
  var SkeletonElementContext: Dynamic;
  var PlatformRootFontSizeContext: Dynamic;
  var SkeletonMotionContext: Dynamic;
  var initializePlatformRootFontSize: Dynamic;
  var jsxPlatformRootFontSize_2: Dynamic;
  var initializePlatformRootFontSize_2: Dynamic;
  var reactPlatformRootFontSize_2: Dynamic;
  var rootRemScaleProperty: Dynamic;
  var PlatformRootFontSizeConstant: Dynamic;
  var PlatformRootFontSizeCss: Dynamic;
  var PlatformRootFontSizeCss_2: Dynamic;
  var CdsRootFontSizeProbeAttribute: Dynamic;
  var scaleCssPixels: Dynamic;
  var PlatformRootFontSizeIsConnectedRemoveState: Dynamic;
  var rootFontSizeObserver: Dynamic;
  var rootFontSizeSnapshot: Dynamic;
  var rootFontSizeSubscribers: Dynamic;
  var initializePlatformRootFontSize_3: Dynamic;
  var iconFontMetadata: Dynamic;
  var initializePlatformRootFontSize_4: Dynamic;
  function ResetSkeletonContext({ children: children }: Dynamic): Dynamic {
    return (
      <SkeletonDecorativeContext.Provider value={false}>
        <SkeletonElementContext.Provider value={"div"}>
          <SkeletonMotionContext.Provider value={null}>
            <PlatformRootFontSizeContext.Provider value={null}>
              {children}
            </PlatformRootFontSizeContext.Provider>
          </SkeletonMotionContext.Provider>
        </SkeletonElementContext.Provider>
      </SkeletonDecorativeContext.Provider>
    );
  }
  function PopupSurface({
    children: children,
    className: className,
    style: style,
    surface: surface,
    density: density,
    companionModalCatcher: companionModalCatcher2 = false,
    closeOnActivityHide = false,
  }: Dynamic): Dynamic {
    let value: Dynamic = (0, runtime.useCloseOnHiddenActivity)(
        closeOnActivityHide,
      ),
      value2: Dynamic = (0, runtime.useMergedRefs)(
        runtime.ensureDocumentInputObserver,
        value,
      ),
      value3: Dynamic = (0, runtime.useDensity)(),
      value4: Dynamic = density ?? value3,
      value5: Dynamic = (0, runtime.useColorMode)(),
      value6: Dynamic = (0, runtime.useThemeId)(),
      value7: Dynamic = (0, runtime.usePlatform)(),
      value8: Dynamic = (0, runtime.useLocale)(),
      value9: Dynamic = (0, runtime.useCdsFont)(),
      value10: Dynamic = (0, runtime.useCdsLabels)(),
      value11: Dynamic = (0, runtime.usePageBackground)(),
      value12: Dynamic = surface ?? value11,
      value13: Dynamic =
        value12 || value9 !== undefined || style
          ? {
              ...(0, runtime.pageBackgroundStyle)(value12),
              ...(0, runtime.monoFontOverrideStyle)(value9),
              ...style,
            }
          : undefined;
    return (
      <div
        ref={value2}
        className={(0, runtime.cn)("cds-root pointer-events-auto", className)}
        data-cds-portal={""}
        data-density={value4}
        data-mode={value5}
        data-cds-theme={value6}
        data-platform={value7}
        data-font={value8}
        data-page-bg={value10}
        style={value13}
        onPointerDown={
          companionModalCatcher2
            ? runtime.preventModalCatcherPointerFocus
            : undefined
        }
        onMouseDown={
          companionModalCatcher2
            ? runtime.preventModalCatcherMouseFocus
            : undefined
        }
        onDragStart={
          companionModalCatcher2
            ? runtime.handleModalCatcherDismissal
            : undefined
        }
      >
        <runtime.DensityContextAlias.Provider value={value4}>
          <runtime.PageBackgroundContext.Provider value={value12}>
            <runtime.RootPresenceContext.Provider value={true}>
              <runtime.DisabledContext.Provider value={false}>
                <ResetSkeletonContext>{children}</ResetSkeletonContext>
              </runtime.DisabledContext.Provider>
            </runtime.RootPresenceContext.Provider>
          </runtime.PageBackgroundContext.Provider>
        </runtime.DensityContextAlias.Provider>
      </div>
    );
  }
  function rootFontSizeProbe(): Dynamic {
    (PlatformRootFontSizeIsConnectedRemoveState === null ||
      !PlatformRootFontSizeIsConnectedRemoveState.isConnected) &&
      (PlatformRootFontSizeIsConnectedRemoveState !== null &&
        (rootFontSizeObserver?.unobserve(
          PlatformRootFontSizeIsConnectedRemoveState,
        ),
        PlatformRootFontSizeIsConnectedRemoveState.remove()),
      (PlatformRootFontSizeIsConnectedRemoveState =
        (document as Dynamic).documentElement.querySelector(
          `:scope > [${CdsRootFontSizeProbeAttribute}]`,
        ) ?? (document as Dynamic).createElement("div")),
      PlatformRootFontSizeIsConnectedRemoveState.setAttribute(
        "aria-hidden",
        "true",
      ),
      PlatformRootFontSizeIsConnectedRemoveState.setAttribute(
        CdsRootFontSizeProbeAttribute,
        "",
      ),
      (PlatformRootFontSizeIsConnectedRemoveState.style.cssText =
        PlatformRootFontSizeCss_2),
      PlatformRootFontSizeIsConnectedRemoveState.isConnected ||
        (document as Dynamic).documentElement.appendChild(
          PlatformRootFontSizeIsConnectedRemoveState,
        ),
      rootFontSizeObserver?.observe(
        PlatformRootFontSizeIsConnectedRemoveState,
      ));
    return PlatformRootFontSizeIsConnectedRemoveState;
  }
  function measureRootRemScale(probe?: Dynamic): Dynamic {
    let fontSizeMatch: Dynamic = /^([\d.]+)px$/.exec(
        getComputedStyle(probe).fontSize,
      ),
      scale: Dynamic =
        fontSizeMatch === null
          ? NaN
          : Number(fontSizeMatch[1]) / PlatformRootFontSizeConstant;
    return scale > 0
      ? scale
      : parseFloat(
          getComputedStyle((document as Dynamic).documentElement).fontSize,
        ) || 16;
  }
  function readRootFontSize(): Dynamic {
    return typeof document === "undefined"
      ? 16
      : measureRootRemScale(rootFontSizeProbe());
  }
  function getRootFontSizeSnapshot(): Dynamic {
    rootFontSizeSnapshot ??= readRootFontSize();
    return rootFontSizeSnapshot;
  }
  function getServerRootFontSize(): Dynamic {
    return 16;
  }
  function subscribeRootFontSize(input?: Dynamic): Dynamic {
    rootFontSizeSubscribers.add(input);
    if (
      rootFontSizeObserver === null &&
      typeof document !== "undefined" &&
      typeof ResizeObserver !== "undefined"
    ) {
      let value: Dynamic = rootFontSizeProbe();
      rootFontSizeObserver = new ResizeObserver((): Dynamic => {
        let value2: Dynamic = readRootFontSize();
        if (value2 !== rootFontSizeSnapshot) {
          rootFontSizeSnapshot = value2;
          for (let value3 of rootFontSizeSubscribers as Dynamic) value3();
        }
      });
      rootFontSizeObserver.observe(value);
    }
    return (): Dynamic => {
      rootFontSizeSubscribers.delete(input);
      rootFontSizeSubscribers.size === 0 &&
        (rootFontSizeObserver?.disconnect(),
        (rootFontSizeObserver = null),
        (rootFontSizeSnapshot = null));
    };
  }
  function useRootFontSize(): Dynamic {
    return (0, reactPlatformRootFontSize_2.useSyncExternalStore)(
      subscribeRootFontSize,
      getRootFontSizeSnapshot,
      getServerRootFontSize,
    );
  }
  bindRuntimeValue(runtime, "ResetSkeletonContext", () => ResetSkeletonContext);
  bindRuntimeValue(
    runtime,
    "reactPlatformRootFontSize",
    () => reactPlatformRootFontSize,
    (value) => {
      reactPlatformRootFontSize = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "jsxPlatformRootFontSize",
    () => jsxPlatformRootFontSize,
    (value) => {
      jsxPlatformRootFontSize = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "SkeletonDecorativeContext",
    () => SkeletonDecorativeContext,
    (value) => {
      SkeletonDecorativeContext = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "SkeletonElementContext",
    () => SkeletonElementContext,
    (value) => {
      SkeletonElementContext = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "PlatformRootFontSizeContext",
    () => PlatformRootFontSizeContext,
    (value) => {
      PlatformRootFontSizeContext = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "SkeletonMotionContext",
    () => SkeletonMotionContext,
    (value) => {
      SkeletonMotionContext = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "initializePlatformRootFontSize",
    () => initializePlatformRootFontSize,
    (value) => {
      initializePlatformRootFontSize = value;
    },
  );
  bindRuntimeValue(runtime, "PopupSurface", () => PopupSurface);
  bindRuntimeValue(
    runtime,
    "jsxPlatformRootFontSize_2",
    () => jsxPlatformRootFontSize_2,
    (value) => {
      jsxPlatformRootFontSize_2 = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "initializePlatformRootFontSize_2",
    () => initializePlatformRootFontSize_2,
    (value) => {
      initializePlatformRootFontSize_2 = value;
    },
  );
  bindRuntimeValue(runtime, "rootFontSizeProbe", () => rootFontSizeProbe);
  bindRuntimeValue(runtime, "measureRootRemScale", () => measureRootRemScale);
  bindRuntimeValue(runtime, "readRootFontSize", () => readRootFontSize);
  bindRuntimeValue(
    runtime,
    "getRootFontSizeSnapshot",
    () => getRootFontSizeSnapshot,
  );
  bindRuntimeValue(
    runtime,
    "getServerRootFontSize",
    () => getServerRootFontSize,
  );
  bindRuntimeValue(
    runtime,
    "subscribeRootFontSize",
    () => subscribeRootFontSize,
  );
  bindRuntimeValue(runtime, "useRootFontSize", () => useRootFontSize);
  bindRuntimeValue(
    runtime,
    "reactPlatformRootFontSize_2",
    () => reactPlatformRootFontSize_2,
    (value) => {
      reactPlatformRootFontSize_2 = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "rootRemScaleProperty",
    () => rootRemScaleProperty,
    (value) => {
      rootRemScaleProperty = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "PlatformRootFontSizeConstant",
    () => PlatformRootFontSizeConstant,
    (value) => {
      PlatformRootFontSizeConstant = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "PlatformRootFontSizeCss",
    () => PlatformRootFontSizeCss,
    (value) => {
      PlatformRootFontSizeCss = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "PlatformRootFontSizeCss_2",
    () => PlatformRootFontSizeCss_2,
    (value) => {
      PlatformRootFontSizeCss_2 = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "CdsRootFontSizeProbeAttribute",
    () => CdsRootFontSizeProbeAttribute,
    (value) => {
      CdsRootFontSizeProbeAttribute = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "scaleCssPixels",
    () => scaleCssPixels,
    (value) => {
      scaleCssPixels = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "PlatformRootFontSizeIsConnectedRemoveState",
    () => PlatformRootFontSizeIsConnectedRemoveState,
    (value) => {
      PlatformRootFontSizeIsConnectedRemoveState = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "rootFontSizeObserver",
    () => rootFontSizeObserver,
    (value) => {
      rootFontSizeObserver = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "rootFontSizeSnapshot",
    () => rootFontSizeSnapshot,
    (value) => {
      rootFontSizeSnapshot = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "rootFontSizeSubscribers",
    () => rootFontSizeSubscribers,
    (value) => {
      rootFontSizeSubscribers = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "initializePlatformRootFontSize_3",
    () => initializePlatformRootFontSize_3,
    (value) => {
      initializePlatformRootFontSize_3 = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "iconFontMetadata",
    () => iconFontMetadata,
    (value) => {
      iconFontMetadata = value;
    },
  );
  bindRuntimeValue(
    runtime,
    "initializePlatformRootFontSize_4",
    () => initializePlatformRootFontSize_4,
    (value) => {
      initializePlatformRootFontSize_4 = value;
    },
  );
  return () => {
    initializePlatformRootFontSize = (0, runtime.initializeOnce)(
      (): Dynamic => {
        "use client";

        reactPlatformRootFontSize = (0, runtime.toModuleNamespace)(
          (0, runtime.load_react)(),
        );
        jsxPlatformRootFontSize = (0, runtime.toModuleNamespace)(
          (0, runtime.load_react_jsx_runtime)(),
        );
        SkeletonDecorativeContext = (0,
        reactPlatformRootFontSize.createContext)(false);
        SkeletonElementContext = (0, reactPlatformRootFontSize.createContext)(
          "div",
        );
        PlatformRootFontSizeContext = (0,
        reactPlatformRootFontSize.createContext)(null);
        SkeletonMotionContext = (0, reactPlatformRootFontSize.createContext)(
          null,
        );
      },
    );
    initializePlatformRootFontSize_2 = (0, runtime.initializeOnce)(
      (): Dynamic => {
        "use client";

        (0, runtime.initializeDomInputObservation)();
        (0, runtime.initializeExperimentalTheme)();
        (0, runtime.initializeClassNames)();
        (0, runtime.initializeCdsRoot)();
        (0, runtime.initializeDomRefComposition_3)();
        (0, runtime.initializeDomRefComposition_4)();
        (0, runtime.initializeDomRefComposition_5)();
        (0, runtime.initializeDomRefComposition)();
        initializePlatformRootFontSize();
        jsxPlatformRootFontSize_2 = (0, runtime.toModuleNamespace)(
          (0, runtime.load_react_jsx_runtime)(),
        );
      },
    );
    initializePlatformRootFontSize_3 = (0, runtime.initializeOnce)(
      (): Dynamic => {
        "use client";

        reactPlatformRootFontSize_2 = (0, runtime.toModuleNamespace)(
          (0, runtime.load_react)(),
        );
        rootRemScaleProperty = "--cds-rem-scale";
        PlatformRootFontSizeConstant = 16;
        PlatformRootFontSizeCss = `calc(${PlatformRootFontSizeConstant}rem * var(${rootRemScaleProperty}, 1))`;
        PlatformRootFontSizeCss_2 = `position:fixed;top:0;left:0;width:${PlatformRootFontSizeCss};min-width:0;max-width:none;height:0;font-size:${PlatformRootFontSizeCss};-webkit-text-size-adjust:none;text-size-adjust:none;visibility:hidden;pointer-events:none;`;
        CdsRootFontSizeProbeAttribute = "data-cds-root-font-size-probe";
        scaleCssPixels = (input: number): string =>
          `calc(${input / 16}rem * var(${rootRemScaleProperty}, 1))`;
        PlatformRootFontSizeIsConnectedRemoveState = null;
        rootFontSizeObserver = null;
        rootFontSizeSnapshot = null;
        rootFontSizeSubscribers = new Set();
      },
    );
    initializePlatformRootFontSize_4 = (0, runtime.initializeOnce)(
      (): Dynamic => {
        iconFontMetadata = JSON.parse(`{
 "icons": {
  "Activity": 57344,
  "Add": 57345,
  "AddCircle": 57346,
  "Agent": 57347,
  "Alarm": 57348,
  "Android": 57349,
  "Ant": 57350,
  "Apple": 57351,
  "Archive": 57352,
  "ArrowDown": 57353,
  "ArrowDownCircle": 57354,
  "ArrowInSquare": 57355,
  "ArrowLeft": 57356,
  "ArrowLeftCircle": 57357,
  "ArrowOutSquare": 57358,
  "ArrowReturn": 57359,
  "ArrowRight": 57360,
  "ArrowRightCircle": 57361,
  "ArrowSplitRight": 57362,
  "ArrowUp": 57363,
  "ArrowUpCircle": 57364,
  "ArrowUpRight": 57365,
  "ArrowsOut": 57366,
  "Artifacts": 57367,
  "Atom": 57368,
  "Attachment": 57369,
  "Batch": 57370,
  "Beaker": 57371,
  "Binoculars": 57372,
  "Book": 57373,
  "BookClosed": 57374,
  "BookText": 57375,
  "Box": 57376,
  "BrowseSelect": 57377,
  "Bullhorn": 57378,
  "Cache": 57379,
  "Calendar": 57380,
  "Camera": 57381,
  "Capacity": 57382,
  "CaretDown": 57383,
  "CaretDownUp": 57384,
  "CaretLeft": 57385,
  "CaretRight": 57386,
  "CaretUp": 57387,
  "CaretUpDown": 57388,
  "ChangesPlusMinus": 57389,
  "ChangesPlusMinusFilled": 57390,
  "Chart": 57391,
  "ChartLine": 57392,
  "Chat": 57393,
  "ChatAdd": 57394,
  "ChatAddFilled": 57395,
  "ChatDelete": 57396,
  "ChatDeleteFilled": 57397,
  "ChatFilled": 57398,
  "ChatSimple": 57399,
  "ChatSimpleFilled": 57400,
  "Chats": 57401,
  "ChatsFilled": 57402,
  "Check": 57403,
  "CheckCircle": 57404,
  "CheckCircleFilled": 57405,
  "CheckDouble": 57406,
  "Checklist": 57407,
  "ChecklistFilled": 57408,
  "Clipboard": 57409,
  "ClipboardArrow": 57410,
  "Clock": 57411,
  "Cloud": 57412,
  "CloudFilled": 57413,
  "CloudSlash": 57414,
  "CloudSlashFilled": 57415,
  "Code": 57416,
  "CodeBlock": 57417,
  "CodeBrackets": 57418,
  "CodeFilled": 57419,
  "CoffeeCup": 57420,
  "Collapse": 57421,
  "CommandCard": 57422,
  "CommandLine": 57423,
  "CommandLineFilled": 57424,
  "CommandLinePrompt": 57425,
  "Compact": 57426,
  "Computer": 57427,
  "Concierge": 57428,
  "Connectors": 57429,
  "Copy": 57430,
  "Create": 57431,
  "CreditCard": 57432,
  "Cursor": 57433,
  "CursorFilled": 57434,
  "DNA": 57435,
  "Database": 57436,
  "Disconnect": 57437,
  "Dispatch": 57438,
  "DollarSign": 57439,
  "DotsCircle": 57440,
  "DotsHorizontal": 57441,
  "DotsVertical": 57442,
  "Download": 57443,
  "Edit": 57444,
  "Email": 57445,
  "Evals": 57446,
  "Expand": 57447,
  "ExtendedThinking": 57448,
  "Eye": 57449,
  "EyeSlash": 57450,
  "Fastforward": 57451,
  "File": 57452,
  "FileAdd": 57453,
  "FileUpload": 57454,
  "Files": 57455,
  "Filter": 57456,
  "Flag": 57457,
  "Folder": 57458,
  "FolderOpen": 57459,
  "FolderPlus": 57460,
  "Ghost": 57461,
  "GhostFilled": 57462,
  "Gift": 57463,
  "GitBranch": 57464,
  "GitCommit": 57465,
  "GitDiff": 57466,
  "GitFork": 57467,
  "GitMerge": 57468,
  "GitMergeConflict": 57469,
  "GitMergedSimple": 57470,
  "GitPullRequest": 57471,
  "GitPullRequestClosed": 57472,
  "GitPullRequestDraft": 57473,
  "Globe": 57474,
  "GraduationCap": 57475,
  "Grid": 57476,
  "Hand": 57477,
  "HandHeart": 57478,
  "Haptics": 57479,
  "Help": 57480,
  "History": 57481,
  "Home": 57482,
  "ID": 57483,
  "Image": 57484,
  "Indent": 57485,
  "InfoSimple": 57486,
  "Info": 57487,
  "Interactive": 57488,
  "Key": 57489,
  "Keyboard": 57490,
  "Laptop": 57491,
  "LaptopFilled": 57492,
  "LaptopSlash": 57493,
  "Library": 57494,
  "Lightbulb": 57495,
  "Lightning": 57496,
  "Link": 57497,
  "LinkSimple": 57498,
  "ListAdd": 57499,
  "ListBullet": 57500,
  "ListNumbered": 57501,
  "Location": 57502,
  "LocationQuestionMark": 57503,
  "LocationSlash": 57504,
  "Lock": 57505,
  "LockOpen": 57506,
  "LockShield": 57507,
  "Logout": 57508,
  "Mailbox": 57509,
  "MapPin": 57510,
  "Mcp": 57511,
  "Memory": 57512,
  "Mention": 57513,
  "Menu": 57514,
  "Microphone": 57515,
  "MicrophoneFilled": 57516,
  "MicrophoneSlash": 57517,
  "Minus": 57518,
  "MobilePhone": 57519,
  "Moon": 57520,
  "MoonFilled": 57521,
  "MoonStars": 57522,
  "Note": 57523,
  "Notification": 57524,
  "NotificationSlash": 57525,
  "Organization": 57526,
  "Owl": 57527,
  "Palette": 57528,
  "PaletteFilled": 57529,
  "PaperPlane": 57530,
  "Pause": 57531,
  "Phone": 57532,
  "Pin": 57533,
  "PinFilled": 57534,
  "PinSlash": 57535,
  "Placeholder": 57536,
  "Play": 57537,
  "PlayCircle": 57538,
  "PlayCircleFilled": 57539,
  "PlayFilled": 57540,
  "Plugin": 57541,
  "Press": 57542,
  "Pro": 57543,
  "Prohibit": 57544,
  "Projects": 57545,
  "ProjectsFilled": 57546,
  "ProjectsX": 57547,
  "Prompt": 57548,
  "Recording": 57549,
  "Reorder": 57551,
  "Research": 57552,
  "Screenshare": 57553,
  "Scroll": 57554,
  "Search": 57555,
  "SearchCircle": 57556,
  "Select": 57557,
  "Settings": 57558,
  "Shapes": 57559,
  "ArrowBendUpRight": 57560,
  "ShareAndroid": 57561,
  "Share": 57562,
  "ShieldSearch": 57563,
  "Shuffle": 57564,
  "Sidebar": 57565,
  "SidebarClose": 57566,
  "SidebarOpen": 57567,
  "Signpost": 57568,
  "SlashShortcutCommand": 57569,
  "Slides": 57570,
  "Sort": 57571,
  "Speaker": 57572,
  "Spinner": 57573,
  "Spreadsheet": 57574,
  "Star": 57575,
  "StarFilled": 57576,
  "StarSlash": 57577,
  "Stop": 57578,
  "StopCircle": 57579,
  "StopFilled": 57580,
  "Styles": 57581,
  "Sun": 57582,
  "SunFilled": 57583,
  "SunHorizon": 57584,
  "Tasks": 57585,
  "Team": 57586,
  "Temperature": 57587,
  "TemperatureSimple": 57588,
  "TextAa": 57589,
  "TextBold": 57590,
  "TextItalics": 57591,
  "TextUnderline": 57592,
  "ThumbsDown": 57593,
  "ThumbsDownFilled": 57594,
  "ThumbsUp": 57595,
  "ThumbsUpFilled": 57596,
  "Timer": 57597,
  "Toggles": 57598,
  "Token": 57599,
  "Tool": 57600,
  "Trash": 57601,
  "Trust": 57602,
  "Upload": 57603,
  "User": 57604,
  "UserCircle": 57605,
  "Users": 57606,
  "Verified": 57607,
  "Voice": 57608,
  "Warning": 57609,
  "WarningCircle": 57610,
  "WarningShield": 57611,
  "Workspace": 57612,
  "Wrench": 57613,
  "WrenchFilled": 57614,
  "X": 57615,
  "XCircle": 57616,
  "GitMergeQueue": 57617,
  "Orbit": 57618,
  "SidebarRight": 57619,
  "Bluetooth": 57621,
  "BluetoothSlash": 57622,
  "Bookmark": 57623,
  "ComputerClassic": 57624,
  "Linux": 57625,
  "Windows": 57626,
  "AgentSimple": 57627,
  "AgentsSimple": 57628,
  "ArrowClockwise": 57629,
  "ArrowCounterClockwise": 57630,
  "MinimizeBottomLeft": 57631,
  "MinimizeBottomRight": 57632,
  "MinimizeTopLeft": 57633,
  "MinimizeTopRight": 57634,
  "EyeFrame": 57635,
  "Frame": 57636,
  "Hammer": 57637,
  "HealthConnect": 57638,
  "Heart": 57639,
  "Scale": 57640,
  "ArrowDownLeft": 57641,
  "ArrowDownRight": 57642,
  "ArrowUpLeft": 57643,
  "Bank": 57644,
  "Goal": 57645,
  "ProgressQuarter": 57646,
  "UsageGaugeHigh": 57647,
  "UsageGaugeMiddle": 57648,
  "EditFilled": 57649,
  "Quote": 57650,
  "MemorySlash": 57651,
  "AddLarge": 57652,
  "Ticket": 57653,
  "WindowNew": 57654,
  "BookmarkFilled": 57655,
  "AlignStretch": 57656,
  "ArrowLine": 57657,
  "Crop": 57658,
  "Diagram": 57659,
  "Dropdown": 57660,
  "Eraser": 57661,
  "EyeDropper": 57662,
  "FrameHash": 57663,
  "Heading1": 57664,
  "Heading2": 57665,
  "Heading3": 57666,
  "JustifyCenter": 57667,
  "LineHeight": 57668,
  "LineSegment": 57669,
  "Outdent": 57670,
  "Sigma": 57671,
  "Table": 57672,
  "TextAlignCenter": 57673,
  "TextAlignJustify": 57674,
  "TextAlignLeft": 57675,
  "TextAlignRight": 57676,
  "TextHighlight": 57677,
  "TextT": 57678,
  "ZoomIn": 57679,
  "ZoomOut": 57680,
  "AlignCenter": 57681,
  "AlignEnd": 57682,
  "AlignStart": 57683,
  "CornerBottomLeft": 57684,
  "CornerBottomRight": 57685,
  "CornerTopLeft": 57686,
  "CornerTopRight": 57687,
  "JustifyEnd": 57688,
  "JustifySpaceBetween": 57689,
  "JustifyStart": 57690,
  "LetterSpacing": 57691,
  "TableCellSplit": 57692,
  "TableCellsMerge": 57693,
  "TableColumnDelete": 57694,
  "TableColumnInsertLeft": 57695,
  "TableColumnInsertRight": 57696,
  "TableRowDelete": 57697,
  "TableRowInsertAbove": 57698,
  "TableRowInsertBelow": 57699,
  "Smiley": 57719,
  "SmileyAdd": 57720,
  "SideBottom": 57721,
  "SideLeft": 57722,
  "SideRight": 57723,
  "SideTop": 57724
 },
 "secondary": {
  "AlignCenter": 57700,
  "AlignEnd": 57701,
  "AlignStart": 57702,
  "CornerBottomLeft": 57703,
  "CornerBottomRight": 57704,
  "CornerTopLeft": 57705,
  "CornerTopRight": 57706,
  "JustifyEnd": 57707,
  "JustifySpaceBetween": 57708,
  "JustifyStart": 57709,
  "LetterSpacing": 57710,
  "TableCellSplit": 57711,
  "TableCellsMerge": 57712,
  "TableColumnDelete": 57713,
  "TableColumnInsertLeft": 57714,
  "TableColumnInsertRight": 57715,
  "TableRowDelete": 57716,
  "TableRowInsertAbove": 57717,
  "TableRowInsertBelow": 57718,
  "SideBottom": 57725,
  "SideLeft": 57726,
  "SideRight": 57727,
  "SideTop": 57728
 },
 "next": 57729,
 "wght": {
  "16": {
   "lo": 0.8,
   "hi": 1.25
  },
  "20": {
   "lo": 1.125,
   "hi": 1.8
  }
 },
 "anim": [
  "Artifacts",
  "Chart",
  "Chats",
  "Clock",
  "Code",
  "Download",
  "Lightbulb",
  "Palette",
  "Projects",
  "Signpost",
  "Tasks",
  "Tool"
 ],
 "animLoop": [
  "Code"
 ],
 "animDur": {
  "Palette": 800
 },
 "animDurOut": {
  "Palette": 0
 },
 "animEase": {
  "Palette": "ease-out"
 }
}`);
      },
    );
  };
}
